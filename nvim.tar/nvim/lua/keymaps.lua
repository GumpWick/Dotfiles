-- space bar leader key
vim.g.mapleader = " "

 -- buffers
vim.keymap.set("n", "<leader>n", ":bn<cr>",  { silent = true })
vim.keymap.set("n", "<leader>b", ":bp<cr>",  { silent = true })

vim.keymap.set("n", ";", ":bn<cr>",  { silent = true })
vim.keymap.set("n", ",", ":bp<cr>",  { silent = true })

--Comme pour dwm, <C-j> permet de changer de fenêtres (ici dans nvim ce sont des splits)
vim.keymap.set("n", "<C-j>", "<C-w><C-w>",  { silent = true })


--buffer 2 n'existe pas apparement donc décalage obligatoire
vim.keymap.set("n", "<leader>&", ":buffer 1<CR>", { silent = true })
vim.keymap.set("n", "<leader>é", ":buffer 3<CR>", { silent = true })
vim.keymap.set("n", "<leader>\"", ":buffer 4<CR>", { silent = true })
vim.keymap.set("n", "<leader>'", ":buffer 5<CR>", { silent = true })
vim.keymap.set("n", "<leader>(", ":buffer 6<CR>", { silent = true })
vim.keymap.set("n", "<leader>-", ":buffer 7<CR>", { silent = true })
vim.keymap.set("n", "<leader>è", ":buffer 8<CR>", { silent = true })
vim.keymap.set("n", "<leader>_", ":buffer 9<CR>", { silent = true })
vim.keymap.set("n", "<leader>ç", ":buffer 10<CR>", { silent = true })

vim.keymap.set("n", "<leader>N", ":tabn<cr>",  { silent = true })

-- a pour avantage de pas briser le layout (si je suis en split windows) donc c'est bien different de :bd
vim.keymap.set("n", "<leader>c", ":Bdelete<cr>",  { silent = true })



vim.keymap.set("n", "<C-d>", "<C-d>zz")
vim.keymap.set("n", "<C-u>", "<C-u>zz")

-- Center the screen on the next/prev search result with n/N
vim.keymap.set("n", "n", "nzzzv")
vim.keymap.set("n", "N", "Nzzzv")


-- windows
vim.keymap.set("n", "<leader><left>", ":vertical resize +10<cr>")
vim.keymap.set("n", "<leader><right>", ":vertical resize -10<cr>")
vim.keymap.set("n", "<leader><up>", ":resize +10<cr>")
vim.keymap.set("n", "<leader><down>", ":resize -10<cr>")


-- Définir un autocmd pour ajuster le raccourci en fonction du type de fichier
vim.api.nvim_create_autocmd("FileType", {
  pattern = "*",
  callback = function()
    local filetype = vim.bo.filetype

    if filetype == "python" then
      -- Si le fichier est de type Python, utiliser black pour formater
      vim.keymap.set("n", "<leader>fm", ":silent !autopep8 --indent-size 2 --in-place %<cr>", { noremap = true, silent = true, buffer = true })


    else
      -- Sinon, utiliser la fonction LSP pour formater
      vim.keymap.set("n", "<leader>fm", vim.lsp.buf.format, { noremap = true, silent = true, buffer = true })
    end
  end
})


vim.api.nvim_set_keymap('n', 'p', "p`[v`]=<CR>`]", { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', 'P', "P`[v`]=<CR>`]", { noremap = true, silent = true })
vim.api.nvim_set_keymap('x', 'p', '"_PP`[v`]=<CR>`]', { noremap = true, silent = true })


-- -- CODE DEPASSÉ: c'est une save ou cas où
-- vim.api.nvim_set_keymap('v', 'p', '"_dP`[v`]=<CR>`]', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('x', 'p', '0"_dO<Esc>P`[v`]=<CR>`]', { noremap = true, silent = true })






-- vim.api.nvim_set_keymap('x', 'P', '0"_dP`[v`]=<CR>`]', { noremap = true, silent = true })

-- vim.api.nvim_set_keymap('v', 'y', "y`[V$`]=<CR>`[", { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('x', 'p', '0"_dP`[v`]=<CR>`]$a<CR><Esc>k$', { noremap = true, silent = true })
-- vim.keymap.set("x", "p", [["_dP]])

-- Remap arrow keys to move all cursors in visual multi mode
-- vim.g.VM_maps = {
--   ["Move Left"]  = "<Left>",
--   ["Move Down"]  = "<Down>",
--   ["Move Up"]    = "<Up>",
--   ["Move Right"] = "<Right>",
-- }

-- Remapper les touches directionnelles
-- vim.api.nvim_set_keymap('n', '<Up>', 'k', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('n', '<Down>', 'j', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('n', '<Left>', 'h', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('n', '<Right>', 'l', { noremap = true, silent = true })

vim.api.nvim_set_keymap(
  'n', -- mode 'i' pour 'insert mode'
  '<leader>m', -- le raccourci, ici Leader + m
  'iint main(int argc, char *argv[]) {\n\nreturn 0;\n}', -- le texte à insérer
  { noremap = true, silent = true }
)



-- Remap for moving lines up and down in normal mode
vim.keymap.set('n', 'K', ':m .-2<CR>==', { noremap = true, silent = true })
vim.keymap.set('n', 'J', ':m .+1<CR>==', { noremap = true, silent = true })

-- Remap for moving lines up and down in visual mode
vim.keymap.set('v', 'K', ":m '<-2<CR>gv=gv", { noremap = true, silent = true })
vim.keymap.set('v', 'J', ":m '>+1<CR>gv=gv", { noremap = true, silent = true })

