-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
  local lazyrepo = "https://github.com/folke/lazy.nvim.git"
  local out = vim.fn.system({ "git", "clone", "--filter=blob:none", "--branch=stable", lazyrepo, lazypath })
  if vim.v.shell_error ~= 0 then
    vim.api.nvim_echo({
      { "Failed to clone lazy.nvim:\n", "ErrorMsg" },
      { out,                            "WarningMsg" },
      { "\nPress any key to exit..." },
    }, true, {})
    vim.fn.getchar()
    os.exit(1)
  end
end
vim.opt.rtp:prepend(lazypath)


require("lazy").setup({
  { "catppuccin/nvim",               name = "catppuccin", priority = 1000 },
  { "rafi/awesome-vim-colorschemes", priority = 1000 },
  -- { "joshdick/onedark.vim", name = "onedark", priority = 1000 },

  {
    'nvim-telescope/telescope.nvim',
    tag = '0.1.8',
    dependencies = { 'nvim-lua/plenary.nvim' },
    config = function()
    end
  },

  {
    "nvim-tree/nvim-tree.lua",
    version = "*",
    lazy = false,
    requires = {
      "nvim-tree/nvim-web-devicons",
    },
    config = function()
      require("nvim-tree").setup {
        sort = { sorter = "case_sensitive" },
        view = {
          width = 30,
          adaptive_size = true,
        },
        renderer = { group_empty = true },
        filters = { dotfiles = false },
      }
    end,
  },

  {
    'akinsho/bufferline.nvim',
    version = "*",
    dependencies = 'nvim-tree/nvim-web-devicons',
  },


  {
    'mg979/vim-visual-multi',
    branch = 'master'
  },

  {
    'numToStr/Comment.nvim',
    opts = {
    }
  },

  {
    "lervag/vimtex",
    lazy = false, -- we don't want to lazy load VimTeX
    -- tag = "v2.15", -- uncomment to pin to a specific release
    init = function()
      -- VimTeX configuration goes here, e.g.
      vim.g.vimtex_view_method = "zathura"
      vim.g.maplocalleader = ","
    end
  },


  {
    'nvim-treesitter/nvim-treesitter',
    build = ':TSUpdate',

    config = function()
      require 'nvim-treesitter.configs'.setup {
        ensure_installed = { 'lua', 'python', 'bash', 'markdown', 'markdown_inline', 'javascript', "c", "vim", "vimdoc", "query", "rust", "typescript", }, -- ou une liste des langages que tu veux
        highlight = { enable = true, additional_vim_regex_highlighting = false, },                                                                         -- active la coloration syntaxique
        indent = { enable = false },                                                                                                                       --METTRE SUR FALSE SINON HORRIBLES LAGS
      }
    end
  },

  {
    "lewis6991/gitsigns.nvim",
    config = function()
      require("gitsigns").setup {
        signs = {
          add = { text = '+' },
          change = { text = '~' },
          delete = { text = '—' },
          topdelete = { text = '—' },
          changedelete = { text = '~' },
        },
        signs_staged = {
          add = { text = '+' },
          change = { text = '~' },
          delete = { text = '—' },
          topdelete = { text = '—' },
          changedelete = { text = '~' },
        },
      }
    end,

  },

  -- {
  --   "rbong/vim-flog",
  --   lazy = true,
  --   cmd = { "Flog", "Flogsplit", "Floggit" },
  --   dependencies = {
  --     "tpope/vim-fugitive",
  --   },
  -- },

  {
    'nvim-lualine/lualine.nvim',
    dependencies = { 'nvim-tree/nvim-web-devicons' },
    config = function()
      require('lualine').setup {
        options = {
          icons_enabled = true,
          theme = 'auto',
          component_separators = { left = '', right = '' },
          section_separators = { left = '', right = '' },
          disabled_filetypes = {
            statusline = { "NvimTree" },
            winbar = { "NvimTree" },
          },
          ignore_focus = {},
          always_divide_middle = true,
          always_show_tabline = true,
          globalstatus = false,
          refresh = {
            statusline = 10,
            tabline = 10,
            winbar = 10,
          }
        },
        sections = {
          lualine_a = { 'mode' },
          lualine_b = { 'branch', 'diff', 'diagnostics' },
          lualine_c = { 'filename' },
          lualine_x = { 'encoding', 'fileformat', 'filetype' },
          lualine_y = { 'progress' },
          lualine_z = { 'location' }
        },
        inactive_sections = {
          lualine_a = {},
          lualine_b = {},
          lualine_c = { 'filename' },
          lualine_x = { 'location' },
          lualine_y = {},
          lualine_z = {}
        },
        tabline = {},
        winbar = {},
        inactive_winbar = {},
        extensions = {}
      }
    end,
  },


  -- {"ggandor/leap.nvim"}, -- qd je serai un vim-experienced guy

  {
    "leath-dub/snipe.nvim",
    keys = {
      {
        "<leader><Tab>",
        function()
          require("snipe").open_buffer_menu()
        end,
        desc = "Open Snipe buffer menu",
      },
    },
    config = function()
      local snipe = require("snipe")

      -- Surcharge de la méthode de formatage des buffers
      local function custom_format(buffer)
        local max_path_width = 2
        local path = buffer.path or ""
        -- Troncature des chemins trop longs
        if #path > max_path_width then
          path = "…" .. path:sub(-max_path_width)
        end
        return string.format("[%d] %s", buffer.bufnr, path)
      end

      -- Configuration de Snipe avec la fonction de formatage personnalisée
      snipe.setup({
        hints = {
          dictionary = "123456789",
        },
        navigate = {
          cancel_snipe = "<esc>",
          close_buffer = "d",
          under_cursor = "<Tab>",
        },
        sort = "default",
        buffer_formatter = custom_format, -- Utilisation de notre format personnalisé
      })
    end,
  },


  { "moll/vim-bbye" },

  { "mbbill/undotree" },

  { "hrsh7th/cmp-path" },

  {
    "folke/persistence.nvim",
    event = "BufReadPre",
    opts = {},
    -- stylua: ignore
    keys = {
      { "<leader>qs", function() require("persistence").load() end,                desc = "Restore Session" },
      { "<leader>qS", function() require("persistence").select() end,              desc = "Select Session" },
      { "<leader>ql", function() require("persistence").load({ last = true }) end, desc = "Restore Last Session" },
      { "<leader>qd", function() require("persistence").stop() end,                desc = "Don't Save Current Session" },
    },
  },

  {
    "nvimdev/dashboard-nvim",
    lazy = false, -- As https://github.com/nvimdev/dashboard-nvim/pull/450, dashboard-nvim shouldn't be lazy-loaded to properly handle stdin.
    opts = function()
      local logo = [[
 ███▄    █ ▓█████  ▒█████   ██▒   █▓ ██▓ ███▄ ▄███▓
 ██ ▀█   █ ▓█   ▀ ▒██▒  ██▒▓██░   █▒▓██▒▓██▒▀█▀ ██▒
▓██  ▀█ ██▒▒███   ▒██░  ██▒ ▓██  █▒░▒██▒▓██    ▓██░
▓██▒  ▐▌██▒▒▓█  ▄ ▒██   ██░  ▒██ █░░░██░▒██    ▒██
▒██░   ▓██░░▒████▒░ ████▓▒░   ▒▀█░  ░██░▒██▒   ░██▒
░ ▒░   ▒ ▒ ░░ ▒░ ░░ ▒░▒░▒░    ░ ▐░  ░▓  ░ ▒░   ░  ░
░ ░░   ░ ▒░ ░ ░  ░  ░ ▒ ▒░    ░ ░░   ▒ ░░  ░      ░
   ░   ░ ░    ░   ░ ░ ░ ▒       ░░   ▒ ░░      ░
         ░    ░  ░    ░ ░        ░   ░         ░
                                ░
]]

      logo = string.rep("\n", 8) .. logo .. "\n\n"

      local opts = {
        theme = "doom",
        hide = {
          -- this is taken care of by lualine
          -- enabling this messes up the actual laststatus setting after loading a file
          statusline = false,
        },
        config = {
          header = vim.split(logo, "\n"),
          -- stylua: ignore
          center = {
            { action = ':Telescope find_files', desc = " Find File", icon = " ", key = "f" },
            { action = "ene | startinsert", desc = " New File", icon = " ", key = "n" },
            { action = ":Telescope oldfiles", desc = " Recent Files", icon = " ", key = "r" },
            { action = ':Telescope live_grep', desc = " Find Text", icon = " ", key = "g" },
            { action = 'require("telescope.builtin").find_files({ cwd = "~/.config/nvim" })', desc = " Config", icon = " ", key = "c" },
            { action = 'lua require("persistence").load()', desc = " Restore Session", icon = " ", key = "s" },
            { action = "Lazy", desc = " Lazy", icon = "󰒲 ", key = "l" },
            { action = function() vim.api.nvim_input("<cmd>qa<cr>") end, desc = " Quit", icon = " ", key = "q" },
          },
          footer = function()
            local stats = require("lazy").stats()
            local ms = (math.floor(stats.startuptime * 100 + 0.5) / 100)
            return { "⚡ Neovim loaded " .. stats.loaded .. "/" .. stats.count .. " plugins in " .. ms .. "ms" }
          end,
        },
      }

      for _, button in ipairs(opts.config.center) do
        button.desc = button.desc .. string.rep(" ", 43 - #button.desc)
        button.key_format = "  %s"
      end

      -- open dashboard after closing lazy
      if vim.o.filetype == "lazy" then
        vim.api.nvim_create_autocmd("WinClosed", {
          pattern = tostring(vim.api.nvim_get_current_win()),
          once = true,
          callback = function()
            vim.schedule(function()
              vim.api.nvim_exec_autocmds("UIEnter", { group = "dashboard" })
            end)
          end,
        })
      end

      return opts
    end,
  },



  { "sindrets/diffview.nvim" },

  { "tpope/vim-fugitive" },

  {
    "kdheepak/lazygit.nvim",

    cmd = {
      "LazyGit",
      "LazyGitConfig",
      "LazyGitCurrentFile",
      "LazyGitFilter",
      "LazyGitFilterCurrentFile",
    },

    dependencies = {
      "nvim-lua/plenary.nvim",
    },
  },


  {
    {
      'VonHeikemen/lsp-zero.nvim',
      branch = 'v3.x',
      lazy = true,
      config = false,
      init = function()
        -- Disable automatic setup, we are doing it manually
        vim.g.lsp_zero_extend_cmp = 0
        vim.g.lsp_zero_extend_lspconfig = 0
      end,
    },
    {
      'williamboman/mason.nvim',
      lazy = false,
      config = true,
    },


    -- Autocompletion
    {
      'hrsh7th/nvim-cmp',
      event = 'InsertEnter',
      dependencies = {
        {
          -- snippet plugin
          "L3MON4D3/LuaSnip",
          -- dependencies = "rafamadriz/friendly-snippets",
          -- config = function()
          --   local luasnip = require("luasnip")
          --   require("luasnip.loaders.from_vscode").lazy_load { exclude = vim.g.vscode_snippets_exclude or {} }
          --   require("luasnip.loaders.from_vscode").lazy_load { paths = vim.g.vscode_snippets_path or "" }
          --
          --   -- snipmate format
          --   require("luasnip.loaders.from_snipmate").load()
          --   require("luasnip.loaders.from_snipmate").lazy_load { paths = vim.g.snipmate_snippets_path or "" }
          --
          --   -- lua format
          --   require("luasnip.loaders.from_lua").load()
          --   require("luasnip.loaders.from_lua").lazy_load { paths = vim.g.lua_snippets_path or "" }
          --
          --   vim.api.nvim_create_autocmd("InsertLeave", {
          --     callback = function()
          --       if
          --         require("luasnip").session.current_nodes[vim.api.nvim_get_current_buf()]
          --         and not require("luasnip").session.jump_active
          --         then
          --           require("luasnip").unlink_current()
          --         end
          --       end,
          --     })
          -- end,
        },
        {
          "windwp/nvim-autopairs",
          opts = {
            fast_wrap = {},
            disable_filetype = { "TelescopePrompt", "vim" },
          },
          config = function(_, opts)
            require("nvim-autopairs").setup(opts)

            -- setup cmp for autopairs
            local cmp_autopairs = require "nvim-autopairs.completion.cmp"
            require("cmp").event:on("confirm_done", cmp_autopairs.on_confirm_done())
          end,
        },
      },
      config = function()
        local lsp_zero = require('lsp-zero')
        lsp_zero.extend_cmp()

        local cmp = require('cmp')
        local cmp_action = lsp_zero.cmp_action()

        cmp.setup({
          formatting = lsp_zero.cmp_format({ details = true }),
          preselect = cmp.PreselectMode.None,
          mapping = cmp.mapping.preset.insert({
            ['<C-Space>'] = cmp.mapping.complete(),
            ['<C-n>'] = cmp.mapping.select_next_item(), -- Navigue vers l'élément suivant
            ['<C-p>'] = cmp.mapping.select_prev_item(), -- Navigue vers l'élément précédent
            ['<C-u>'] = cmp.mapping.scroll_docs(-4),
            ['<C-d>'] = cmp.mapping.scroll_docs(4),
            ['<C-f>'] = cmp_action.luasnip_jump_forward(),
            ['<C-b>'] = cmp_action.luasnip_jump_backward(),
            ['<Tab>'] = cmp.mapping.confirm {
              behavior = cmp.ConfirmBehavior.Replace,
              select = true,
            },
          }),
          sources = {

            { name = 'nvim_lsp', max_item_count = 10 },                                         -- Limiter les suggestions LSP à 5
            { name = 'luasnip',  options = { show_autosnippets = true }, max_item_count = 10 }, -- Limiter les suggestions LSP à 5
            { name = 'buffer',   max_item_count = 10 },                                         -- Limiter les suggestions du buffer à 5
            { name = 'path',     max_item_count = 10 },                                         -- Limiter les suggestions de chemin à 5
          },

          snippet = {
            expand = function(args)
              require('luasnip').lsp_expand(args.body)
            end,
          },
        })
      end
    },


    -- LSP
    {
      'neovim/nvim-lspconfig',
      cmd = { 'LspInfo', 'LspInstall', 'LspStart' },
      event = { 'BufReadPre', 'BufNewFile' },
      dependencies = {
        { 'hrsh7th/cmp-nvim-lsp' },
        { 'williamboman/mason-lspconfig.nvim' },
      },
      config = function()
        -- This is where all the LSP shenanigans will live
        local lsp_zero = require('lsp-zero')
        lsp_zero.extend_lspconfig()

        local capabilities = vim.lsp.protocol.make_client_capabilities()
        capabilities.textDocument.completion.completionItem.snippetSupport = false

        lsp_zero.on_attach(function(client, bufnr)
          lsp_zero.default_keymaps({ buffer = bufnr })
          local opts = { noremap = true, silent = true }
          vim.keymap.set('n', '<leader>K', '<cmd>lua vim.lsp.buf.hover()<cr>', opts)
          vim.keymap.set('n', '<leader>gd', '<cmd>lua vim.lsp.buf.definition()<cr>', opts)
          vim.keymap.set('n', '<leader>gD', '<cmd>lua vim.lsp.buf.declaration()<cr>', opts)
          vim.keymap.set('n', '<leader>gi', '<cmd>lua vim.lsp.buf.implementation()<cr>', opts)
          vim.keymap.set('n', '<leader>go', '<cmd>lua vim.lsp.buf.type_definition()<cr>', opts)
          vim.keymap.set('n', '<leader>gr', '<cmd>lua vim.lsp.buf.references()<cr>', opts)
          vim.keymap.set('n', '<leader>gs', '<cmd>lua vim.lsp.buf.signature_help()<cr>', opts)
          vim.keymap.set('n', '<leader><F2>', '<cmd>lua vim.lsp.buf.rename()<cr>', opts)
          vim.keymap.set('n', '<leader><F4>', '<cmd>lua vim.lsp.buf.code_action()<cr>', opts)
        end)

        require('mason-lspconfig').setup({
          ensure_installed = {},
          handlers = {
            -- this first function is the "default handler"
            -- it applies to every language server without a "custom handler"
            function(server_name)
              require('lspconfig')[server_name].setup({
                capabilities = capabilities,
              })
            end,

            -- this is the "custom handler" for `lua_ls`
            lua_ls = function()
              local lua_opts = lsp_zero.nvim_lua_ls()
              require('lspconfig').lua_ls.setup(vim.tbl_deep_extend("force", lua_opts, {
                capabilities = capabilities,
              }))
            end,


            pyright = function()
              require('lspconfig').pyright.setup({
                capabilities = capabilities,
                on_attach = function(_, bufnr) -- '_' signifie que le client est ignoré
                  -- Set indentation to 2 spaces for Python
                  vim.bo[bufnr].tabstop = 2
                  vim.bo[bufnr].shiftwidth = 2
                  vim.bo[bufnr].expandtab = true
                  vim.bo[bufnr].autoindent = true
                  vim.bo[bufnr].smartindent = true
                end,
              })
            end,


          }
        })
      end
    }
  }

})
