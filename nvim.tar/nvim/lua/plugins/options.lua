-- METTRE LE FOND du colorscheme DE la meme couleur que mon terminal!!!!!!!!!!!!!!!
-- require("catppuccin").setup({
--   custom_highlights = function(colors)
--     return {
--       Normal = { bg = "none" },
--     }
--   end
-- })


vim.cmd("colorscheme catppuccin-mocha") -- set color theme
-- vim.cmd("colorscheme no-clown-fiesta") -- set color theme

-- vim.cmd("highlight SignColumn guibg=NONE")
vim.o.background = "dark" -- or "light" for light mode

-- Load and setup function to choose plugin and language highlights
vim.g.startify_custom_header = "" -- startify remove random quote

vim.opt.termguicolors = true      --bufferline
require("bufferline").setup {

  -- highlights = require("catppuccin.groups.integrations.bufferline").get(),
  highlights = {
    buffer_selected = {
      bold = true,
      italic = false,
    },
  },

  options = {

    always_show_bufferline = true,
    auto_toggle_bufferline = true,
    indicator = {
      icon = '▎', -- this should be omitted if indicator style is not 'icon'
      style = 'icon'
    },
    -- diagnostics = false,
    -- themable = true,
  },
}


-- permet de renvoyer à la ligne les diagnostics
vim.api.nvim_create_autocmd("FileType", {
  pattern = "qf", -- pour la quickfix et loclist
  callback = function()
    vim.wo.wrap = true
  end,
})

