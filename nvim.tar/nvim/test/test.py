

def okay_print_array(n):
    for _ in range(5):

        print("otestevrv")

    return n
